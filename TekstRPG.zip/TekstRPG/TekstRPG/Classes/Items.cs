namespace TekstRPG.Classes;

public class Items
{

    public int Id { get; set; }
    public string name { get; set; }
    public int stacked { get; set; }

    public Items(int Id, string name, int stacked)
    {
        this.Id = Id;
        this.name = name;
        this.stacked = stacked;
    }

}