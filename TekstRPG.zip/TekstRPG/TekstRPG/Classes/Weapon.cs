using System.Collections.Generic;

namespace TekstRPG.Classes;

public class Weapon
{
    public  int Id { get; set; }
    public string name { get; set; }
    public int weaponDamage { get; set; }
    public bool twoWeapons { get; set; }
    public int armor { get; set; }
    public bool equiped { get; set; }

    public Weapon(int Id, string name, int weaponDamage, bool twoWeapons, int armor, bool equiped)
    {
        this.Id = Id;
        this.name = name;
        this.weaponDamage = weaponDamage;
        this.twoWeapons = twoWeapons;
        this.armor = armor;
        this.equiped = equiped;
    }
    
}