using System.Net;
using System.Collections.Generic;
using System.Drawing;
using Pastel;

namespace TekstRPG.Classes;

public class Town
{
    public string TutorialTownBlacksmith()
    {
        Console.Clear();
        var tutorialBlacksmithText = "You are escorted back to the city by Sir Pupset.\n" +
                          "Sir Pupset: First part of my training is getting you a weapon here\n" +
                          "(Sir Pupset gives you a bag of coins for the blacksmith)\n" +
                          "Sir Pupset: Get to the weaponsmith and get some weapons and choose one.\n" +
                          "Sir Pupset: Type 'Blacksmith' to get to the blacksmith, whatever that means.";

        Console.WriteLine(tutorialBlacksmithText);
        
        var gotoBlacksmith = Console.ReadLine();
        if (gotoBlacksmith.Equals("Blacksmith"))
        {
            TutorialBlacksmithShop();
        }
        else
        {
            TutorialTownBlacksmith();
        }
        
        return tutorialBlacksmithText;
    }
    
    public static void TutorialBlacksmithShop()
    {
        Console.Clear();
        Console.WriteLine("You enter the blacksmiths shop\n" +
                          "Blacksmith: Welcome, you here to look at my wares?\n" +
                          "Buy\n" +
                          "Leave");
        var shopChoice = Console.ReadLine();
        if (shopChoice.Equals("Buy"))
        {
            Console.Clear();
            Console.WriteLine("On sale\n" +
                              "Weapons level 1");
            BuyChoice();
        }
        else if (shopChoice.Equals("Leave"))
        {
            Console.Clear();
            Console.WriteLine("You can't leave without bying a weapon.");
            Console.ReadKey();
            TutorialBlacksmithShop();
        }
        else
        {
            TutorialBlacksmithShop();
        }
        
    }

    public static void PickWeapon()
    {
        Console.Clear();
        Console.WriteLine("Sir Pupset: Congratulations, you have bought your first weapons, now choose one\n" +
                          "(Type the corresponding number)\n");

        List<Weapon> weaponBundle1 = new List<Weapon>();
        weaponBundle1.Add(new Weapon(1,"Sword and shield level 1", 5, false, 5, false));
        weaponBundle1.Add(new Weapon(2,"Twohanded sword level 1", 10, false, 0, false));
        weaponBundle1.Add(new Weapon(3,"Daggers level 1", 6, true, 0, false));
        weaponBundle1.Add(new Weapon(4,"Staff level 1", 1, false, 0, false));
        weaponBundle1.Add(new Weapon(5,"Training staff level 1", 7, false, 3, false));

        foreach (Weapon weapon in weaponBundle1)
        {
            Console.WriteLine(weapon.Id + " " + weapon.name);
        }
        
        ChooseWeapon();
        
        Console.WriteLine("Sir Pupset: Now get ready for your training.");
        Console.ReadKey();
        Leveling.Training();

    }

    private static void BuyChoice()
    {
        var shopChoice = Console.ReadLine();
        if (shopChoice.Equals("Weapons level 1"))
        {
            Console.Clear();
                        Console.WriteLine("You have bought weapons level 1 with Sir Pupset's money.");
                        Console.ReadKey();
                        PickWeapon();
        }
        else
        {
            Console.Clear();
            Console.WriteLine("On sale\n" +
                              "Weapons level 1");
            BuyChoice();
        }
    }

    private static void ChooseWeapon()
    {
        var weaponChoice = Console.ReadLine();
        if (weaponChoice.Equals("1"))
        {
            Console.Clear();
            Player.player.weaponStrength += 5;
            Player.player.armor += 5;
            Console.WriteLine("Sir Pupset: A sword and shield? How original.");
        }
        else if (weaponChoice.Equals("2"))
        {
            Console.Clear();
            Player.player.weaponStrength += 10;
            Console.WriteLine("Sir Pupset: Careful where you swing that.");
        }
        else if (weaponChoice.Equals("3"))
        {
            Console.Clear();
            Player.player.weaponStrength += 12;
            Console.WriteLine("Sir Pupset: You know, if it was up to me, backstabbing should stay for enemies.");
        }
        else if (weaponChoice.Equals("4"))
        {
            Player.player.weaponStrength += 1;
            Console.WriteLine($"Sir Pupset: {"Sigh".Pastel(Color.Red)} What are you gonna do with that when you havent learned any magic yet?");
        }
        else if (weaponChoice.Equals("5"))
        {
            Console.Clear();
            Player.player.weaponStrength += 7;
            Player.player.armor += 3;
            Console.WriteLine("Sir Pupset: ... Good choice.");
        }
        else
        {
            Console.Clear();
            PickWeapon();
        }
    }
    
}