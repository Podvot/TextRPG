using TekstRPG.Classes;

namespace TekstRPG;

public class Enemy
{

    public int level { get; set; }
    public string name { get; set; }
    public int health { get; set; }
    public int strength { get; set; }
    public int defense { get; set; }
    
    public Enemy(int level, string name, int health, int strength, int defense)
    {
        this.level = level;
        this.name = name;
        this.health = health;
        this.strength = strength;
        this.defense = defense;
    }

    public static void GetPotion()
    {
        Items potion = new Items(1, "Health potion", 0);
    }

}