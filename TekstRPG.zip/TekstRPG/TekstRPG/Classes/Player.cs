namespace TekstRPG.Classes;

public class Player
{
    public string name;
    public int money = 0;
    public int maxHealth = 20;
    public int health = 15;
    public int armor = 0;
    public int weaponStrength = 8;
    public int level = 1;
    public int potions = 0;
    public bool weaponEquiped = false;

    public static Player player = new Player();

    
    

}