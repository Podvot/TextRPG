﻿using System.Drawing;
using System.Security.Authentication.ExtendedProtection;
using Pastel;

namespace TekstRPG.Classes;

public class Menu
{
    public string introText()
    { 
        var voiceline1 = @"You seem worse for wear, now tell me stranger what is your name?";

        var intro = "As you were sailing the seven seas your ship barges straight into the island you were searching for.\n" +
                    $"As you lay unconscious you feel a {"BONK".Pastel(Color.Red)} to your head and you wake up" + 
                    "on your now stranded boat and in\n front of is a man with a walking stick.\n" + 
                    $"???: {voiceline1} (Enter your name now)";
        
        return intro;
    }

    public string StartGame()
    {
        Console.Clear(); 
        Console.WriteLine("");
        Console.WriteLine($"{introText()}");
        Player.player.name = Console.ReadLine();
        if (Player.player.name == "")
        {
            Console.WriteLine($"???: {"Bonk".Pastel(Color.Red)} very funny, now tell me your name");
            GiveName();
        }
        else if (Player.player.name != "")
        {
            Console.Clear();
            Console.WriteLine($"???: An interesting name, but its not important\n" +
                              $"Sir Pupset: You can call me {"SIR PUPSET".Pastel(Color.Red)}.\n" +
                              $"Sir Pupset: Now make yourself useful and get rid of some pests that have been quite annoying. {"NO QUESTIONS!.".Pastel(Color.Red)}");
            Console.ReadKey();
        }
            
        return introText();
    }

    public string helpText()
    {
        var help = $"Welcome to {"Generic game".Pastel(Color.Yellow)} and im here to explain a few tips.\n" +
                   $"Tip 1: The game is case sensitive, so 'attack' and 'Attack' is not the same.\n" +
                   $"Tip 2: If the game seems stuck, try and press 'Enter' to continue the dialog" +
                   $"Tip 3: When you buy upgrade your gear, it will not automatically equip the new items\n" +
                   $"Tip 4: If you ever feel stuck or dont know what to write for something to happen? Simple type /h and a menu\n" +
                   $"of commands will be shown to you, try and use it now to see how to go back to menu :)";
        
        return help;
    }

    public string ShowHelp()
    {
        Console.Clear();
        Console.WriteLine("");
        Console.WriteLine($"{helpText()}");
        Console.WriteLine("");
        
        return helpText();
    }

    public string credits()
    {
        var cred = "Creator: Marc\n" +
                   "Programming: Marc\n" +
                   "Graphic design: Marc\n" +
                   "Story telling: Marc\n" +
                   "Sound design: Marc\n" +
                   "\n" +
                   "Special thanks: Your mom\n" +
                   "\n" +
                   "Type 'Back' to return to start menu";

        return cred;
    }

    public string ShowCredits()
    {
        Console.Clear();
        Console.WriteLine("");
        Console.WriteLine($"{credits()}");
        Console.WriteLine("");

        return credits();
    }
    
    private static void GiveName()
    {
        Console.ReadKey();
        Menu menu = new Menu();
        menu.StartGame();
    } 
    
}