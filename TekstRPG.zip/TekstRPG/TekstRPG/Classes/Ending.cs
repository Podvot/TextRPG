using System.Drawing;
using Pastel;

namespace TekstRPG.Classes;

public class Ending
{

    public string EndingText()
    {
        Console.Clear();
        var endingText = "Sir Pupset: Well well well, i see you did something for once, you are ready to go out alone,\n" +
                         "Sir Pupset: But you are always welcome back to train further and in different disciplines.\n" +
                         "Sir Pupset: ...\n" +
                         $"Sir Pupset: Or that is what i would have said if there was anything more to this game.\n" +
                         $"Sir Pupset: This is sadly the time to say goodbye for now.\n" +
                         $"\n" +
                         $"Thank you for finishing my demo.\n" +
                         $"Press enter to close game.";

        Console.WriteLine(endingText);
        return endingText;
    }
    
    
}