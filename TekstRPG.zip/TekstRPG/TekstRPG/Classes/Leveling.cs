using System.Drawing;
using Pastel;
using TekstRPG.Classes;

namespace TekstRPG;

public class Leveling
{

    public static void Training()
    {
        Console.Clear();
        Console.WriteLine(TrainingDialog());
        Console.ReadKey();
        Console.WriteLine(TrainingTutorial());
        Console.ReadKey();
        AppleThrowing();
    }

    public static string TrainingDialog()
    {
        var trainingText = "Sir Pupset guides you to a training area.\n" +
                          "\n" +
                          "Sir Pupset: Alright, listen here, if you want to train you getter be quick, im gonna\n" +
                          "throw apples after you from different directions (Left, Up, Right) and you will have to \n" +
                          "hit them with your weapon before they hit you okay?\n" +
                          "";
        return trainingText;
    }

    public static string TrainingTutorial()
    {
          var trainingTutorialText = "Tip: You will have to write 'Left' 'Up' or 'Right' to the corresponding direction an apple is thrown after you\n" +
            $"{"I were really close to make it work but it sadly doesnt print a new direction".Pastel(ConsoleColor.Blue)}\n" +
            "Sir Pupset: You ready? here it comes.\n" +
            "Apples start flying from all directions\n" +
            "\n Press enter to start\n";
          return trainingTutorialText;
    }
    
    
    private static Random rnd = new Random();
    private static int direction = rnd.Next(0,3);
    
    public static void AppleThrowing()
    {
        Console.Clear();
        switch (direction)
        {
            case 0:
                Console.WriteLine("Left");
                break;
            case 1:
                Console.WriteLine("Up");
                break;
            case 2:
                Console.WriteLine("Right");
                break;
        }
        
        if (Player.player.level < 5)
        {
            TrainingLoop();
        }
        else if (Player.player.level >= 5)
        {
            TutorialRevenge();
        }
    }

    private static void TrainingLoop()
    {
        var correspondingThrow = Console.ReadLine();

        switch (direction)
        {
            case 0 when correspondingThrow.Equals("Left"):
                LevelUp();
                break;
            
            case 1 when correspondingThrow.Equals("Up"):
                LevelUp();
                break;

            case 2 when correspondingThrow.Equals("Right"):
                LevelUp();
                break;
            
            default:
                Console.Clear();
                Console.WriteLine($"{"Bonk".Pastel(Color.Red)}");
                Console.ReadKey();
                AppleThrowing();
                break;
        }
    }

    private static void TutorialRevenge()
    {
        Console.Clear();
        Console.WriteLine("Sir Pupset: Alright, thats enough for now, lets try and test your strength again on those pests");
        Console.ReadKey();
        Battles.RevengeTutorial();
    }

    private static void LevelUp()
    {
        Player.player.level += 1;
        Player.player.weaponStrength += 3;
        Player.player.maxHealth += 10;
        Console.WriteLine("Level up!");
        Console.ReadKey();
        AppleThrowing();
    }
    
}