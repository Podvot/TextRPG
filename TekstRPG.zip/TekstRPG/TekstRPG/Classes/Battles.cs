using System.Drawing;
using System.Net;
using Pastel;

namespace TekstRPG.Classes;

public class Battles
{
    public static void TutorialBattle()
    {
        Console.Clear();
        Player.player.health = Player.player.maxHealth;
        Wave1();
        Wave2(); 
    }

    public static void RevengeTutorial()
    {
        Console.Clear();
        Player.player.health = Player.player.maxHealth;
        Wave1();
        Wave2(); 
        Wave3();
    }
    
    public static void Combat(int level, string name, int health, int strength, int defense)
    {
        int l;
        string n;
        int h;
        int s;
        int d;

        l = level;
        n = name;
        h = health;
        s = strength;
        d = defense;
        
        while (Player.player.health > 0 && h > 0)
        {

            Console.WriteLine($"{Player.player.name}: {Player.player.health}");
            
            Console.WriteLine($"{n}: {h}\n");

            Console.WriteLine("=====================\n" +
                              "|Attack      Items  |\n" +
                              "=====================\n");
            
            string combatChoice = Console.ReadLine();
            if (combatChoice.Equals("Attack"))
            {
                
                Console.WriteLine($"{Player.player.name} goes for the attack and deals {Player.player.weaponStrength}");
                h -= Player.player.weaponStrength;
                if (h > 0)
                {
                    Console.WriteLine(
                        $"{n} goes for your ankles and bites dealing {s}");
                    Player.player.health -= s;
                }
                else
                {
                    Console.WriteLine($"The {n} is dead {Player.player.name} has earned {l * 10} copper");
                    Player.player.money += l * 10;
                    Console.WriteLine("");
                }

            }
            else if (combatChoice.Equals("Items"))
            {
                Console.Clear();
                CheckItems();
                UseItem();
            }
            Console.ReadKey();
        }
    }
    
    public static void Wave1()
    {
        Player.player.health = Player.player.maxHealth;
        Console.WriteLine("Combat started:\n" +
                          "Wave 1/3\n" +
                          "A Mole swishes back and forth as it focuses on you");
        Enemy mole = new Enemy(3,"Mole",10,5,0);

        Combat(mole.level,mole.name,mole.health,mole.strength,mole.defense);

        Console.ReadKey();

    }

    public static void Wave2()
    {
        var losing = new Town();
        Console.WriteLine("Wave 2/3\n" +
                          "A Moskito flies forth infront of you");
        Enemy moskito = new Enemy(8, "Moskito", 25, 13, 0);
        Combat(moskito.level,moskito.name,moskito.health,moskito.strength,moskito.defense);

        if (Player.player.health <= 0){
            
            Console.Clear();
            Console.WriteLine("Sir Pupset: ...\n" +
                              "Sir Pupset: Really? beaten by a Moskito?\n" +
                              $"Sir Pupset: {"ATLEAST YOU GIT RID OF THAT DAMNED MOLE".Pastel(Color.Red)}\n" +
                              "Sir Pupset: You are completely useless... follow me to town and i will train you\n" +
                              "You follow Sir Pupset back to town");
            Console.ReadKey();
            Town.TutorialBlacksmithShop();
        }
    }

    private static void Wave3()
    {
        Console.WriteLine(Player.player.money);
        
        Console.WriteLine("Sir Pupset: Holy hell, you might need this\n" +
                          "Wave 3/3\n" +
                          "A large Moskito wearing a crown flies over you");
        ScriptedPotion();

        Enemy kingMoskito = new Enemy(13, "King Moskito", 78, 24, 0);
            
        Combat(kingMoskito.level, kingMoskito.name, kingMoskito.health, kingMoskito.strength, kingMoskito.defense);
        
        EndOfDemo();
    }
    
    public static void EndOfDemo()
    {
        var ending = new Ending();
        ending.EndingText();
    }

    public static void ScriptedPotion()
    {
        var potion = new Items(1, "Health Potion", 0);
        Player.player.potions += 1;
    }

    public static void CheckItems()
    {
        if (Player.player.potions.Equals(0))
        {
            Console.WriteLine("Your bag is empty");
        }
        else if (!Player.player.potions.Equals(0))
        {
            Console.WriteLine("Items in bag\n" +
                              $"Healing potion {Player.player.potions}");
        }
    }

    public static void UseItem()
    {
        var useItem = Console.ReadLine();
        if (useItem.Equals("Healing potion"))
        {
            Player.player.potions -= 1;
            Player.player.health += 50;
            if (Player.player.health > Player.player.maxHealth)
            {
                Player.player.health = Player.player.maxHealth;
            }
        }
    }

}