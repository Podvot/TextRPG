﻿using System.ComponentModel.Design;
using System.Drawing;
using System.Linq.Expressions;
using Pastel;
using TekstRPG.Classes;

/*"ENTER".Pastel(Color.FromArgb(165, 229, 250));

Console.WriteLine($"Press {"ENTER".Pastel(Color.FromArgb(165, 229, 250))} to continue");
var spectrum = new (string color, string letter)[]
{
    ("#124542", "a"),
    ("#185C58", "b"),
    ("#1E736E", "c"),
    ("#248A84", "d"),
    ("#20B2AA", "e"),
    ("#3FBDB6", "f"),
    ("#5EC8C2", "g"),
    ("#7DD3CE", "i"),
    ("#9CDEDA", "j"),
    ("#BBE9E6", "k")
};*/

namespace TekstRPG
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Start();
        }
        
        static void Start()
        {
                Console.Clear();
                Console.WriteLine($"Welcome to {"Generic RPG".Pastel(Color.Yellow)})\n" + $"\n" +
                                  $"New game\n" + 
                                  $"Help\n" + 
                                  $"Credits\n" + 
                                  $"");
                
                var menuChoice = Console.ReadLine();
                switch (menuChoice)
                {
                    case "New game":
                        StartGame();
                        break;
                    case "Help":
                        Help();
                        break;
                    case "Credits":
                        ShowCredits();
                        break;
                    default:
                        Start();
                        break;
                
                }
        }

        private static void Help()
        {
            while (true)
            {
                var menu = new Menu();
                menu.ShowHelp();

                string helpCommand = Console.ReadLine();
                switch (helpCommand)
                {
                    case "/h":
                        menu.ShowHelp();
                        Console.WriteLine("Back");
                        Back();
                        break;

                    case "Back":
                        Start();
                        break;

                    default:
                    {
                        if (helpCommand != "/h" || helpCommand != "Back")
                        {
                            menu.ShowHelp();
                        }

                        break;
                    }
                }
            }

            
            // ReSharper disable once FunctionNeverReturns
        }


        private static void Back()
        {
            var back = Console.ReadLine();
            if (back.Equals("Back"))
            {
                Start();
            }
        }
        
        private static void ShowCredits()
        {
            var menu = new Menu();
            menu.ShowCredits();
            Back();
        }

        private static void StartGame()
        {
            var menu = new Menu();
            var town = new Town();
            menu.StartGame(); 
            Battles.TutorialBattle();

        }
        
    }
}